from flask import Flask, request, jsonify
import hashlib
import base64

app = Flask(__name__)

SECRET = b"supersecretkey"

def insecure_mac(message: bytes) -> str:
    return hashlib.sha1(SECRET + message).hexdigest()

@app.route('/mac', methods=['GET'])
def get_mac():
    message = request.args.get('message', '').encode()
    return jsonify({
        'mac': insecure_mac(message),
        'message': message.decode()
    })

@app.route('/verify', methods=['GET'])
def verify():
    message_base64 = request.args.get('message', '')
    mac = request.args.get('mac', '')
    try:
        message = base64.urlsafe_b64decode(message_base64)
    except:
        return "invalid base64"
    print("Received message:", message)
    print("Computed MAC:", insecure_mac(message))
    if insecure_mac(message) == mac:
        if b"user=admin" in message:
            return "hello admin"
        return "hello client"
    return "invalid"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
