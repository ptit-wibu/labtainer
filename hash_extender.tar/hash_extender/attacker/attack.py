import subprocess
import requests
import base64

orig_msg = b"user=client"
orig_mac = "<YOUR_MAC>"
append_data = b"&user=admin"

for secret_len in range(1, 255):  
    print(f"[*] Trying secret length: {secret_len}")
    result = subprocess.run([
        'hash_extender',
        '--data', orig_msg.decode(),
        '--signature', orig_mac,
        '--append', append_data.decode(),
        '--format', 'sha1',
        '--secret', str(secret_len)
    ], capture_output=True, text=True)

    if result.returncode != 0:
        print(f"[!] Failed to run hash_extender at {secret_len}")
        continue

    lines = result.stdout.splitlines()
    try:
        new_mac = next(l.split(": ")[1] for l in lines if l.startswith("New signature"))
        new_data = next(l.split(": ")[1] for l in lines if l.startswith("New string"))
    except StopIteration:
        print("[!] Parse error")
        continue

    # Chuyển new_data từ hex sang bytes
    try:
        new_data_bytes = bytes.fromhex(new_data)
        new_data_base64 = base64.urlsafe_b64encode(new_data_bytes).decode('ascii')
    except ValueError:
        print(f"[!] Invalid hex string at {secret_len}")
        continue

    # Gửi request
    response = requests.get("http://192.168.5.20:5000/verify", params={
        "message": new_data_base64,
        "mac": new_mac
    })

    print(f"Sent message (base64): {new_data_base64}")
    if "hello admin" in response.text.lower():
        print("\n✅ SUCCESS!")
        print("Secret length:", secret_len)
        print("MAC:", new_mac)
        print("Raw message:", new_data_bytes)
        print("Response:", response.text)
        break
    else:
        print(f"[-] Failed at {secret_len}: {response.text}")
