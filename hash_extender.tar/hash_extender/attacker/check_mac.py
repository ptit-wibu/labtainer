#!/usr/bin/env python3
import requests
import base64
import sys

BASE_URL = "http://192.168.5.20:5000"

def to_bytes(s):
    if isinstance(s, bytes):
        return s
    return s.encode('utf-8')

def get_mac(base_url, message):
    res = requests.get(base_url + "/mac", params={"message": message})
    data = res.json()
    return data['mac'], data['message']

def verify_mac(base_url, message, mac):
    message_bytes = to_bytes(message)
    b64_msg = base64.urlsafe_b64encode(message_bytes)
    if sys.version_info[0] >= 3:
        b64_msg = b64_msg.decode('ascii')  # giữ nguyên dấu '=' padding
    #print("[+] Message      : %s" % message)
    #print("[+] MAC (hex)    : %s" % mac)
    #print("[+] Base64 msg   : %s" % b64_msg)
    res = requests.get(base_url + "/verify", params={
        "message": b64_msg,
        "mac": mac
    })
    print("[+] Server reply : %s" % res.text)

if __name__ == "__main__":
    message = "user=client"
    mac, _ = get_mac(BASE_URL, message)
    verify_mac(BASE_URL, message, mac)

